package com.example.testeeee.Modelo;

public class ChatMessage {
    public String senderId, receiverId, message, dateTime;
}
