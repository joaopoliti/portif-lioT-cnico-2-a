package com.example.testeeee.Adapters;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.lifecycle.Lifecycle;
import androidx.viewpager2.adapter.FragmentStateAdapter;

import com.example.testeeee.Fragmentos.Pendentes;
import com.example.testeeee.Fragmentos.Respondidas;

public class AdapterPagerPerguntas extends FragmentStateAdapter {

    public AdapterPagerPerguntas(@NonNull FragmentManager fragmentManager, @NonNull Lifecycle lifecycle) {
        super(fragmentManager, lifecycle);
    }

    @NonNull
    @Override
    public Fragment createFragment(int position) {
        switch (position){
            case 1:
                //tela da pos 1
                return new Respondidas();


        }
        //tela da pos 2
        return new Pendentes();
    }

    @Override
    public int getItemCount() {
        return 2;
    }
}