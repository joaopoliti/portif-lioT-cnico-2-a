package com.example.testeeee.activityss;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.TextView;

import com.example.testeeee.Adapters.AdapterTemas;
import com.example.testeeee.R;


public class Tela_temas extends AppCompatActivity {
    public static String texto;
    public static String[] temas;
    TextView titulo;
    RecyclerView rvt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_temas);
        //getSupportActionBar().hide();
        titulo = findViewById(R.id.textoTema);
        rvt = findViewById(R.id.RVT);
        titulo.setText(texto);
        AdapterTemas adt = new AdapterTemas(this, temas);
        rvt.setHasFixedSize(true);
        rvt.setLayoutManager(new LinearLayoutManager(this));
        rvt.setAdapter(adt);
        adt.notifyDataSetChanged();
    }
}