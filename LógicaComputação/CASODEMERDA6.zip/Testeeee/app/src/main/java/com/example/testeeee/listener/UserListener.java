package com.example.testeeee.listener;

import com.example.testeeee.Modelo.User;

public interface UserListener {
    void onUserClicked(User user);

}
