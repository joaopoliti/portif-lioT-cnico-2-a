package com.example.testeeee.Modelo;

import java.io.Serializable;

public class User implements Serializable {
    public String nome, image, token;
}
