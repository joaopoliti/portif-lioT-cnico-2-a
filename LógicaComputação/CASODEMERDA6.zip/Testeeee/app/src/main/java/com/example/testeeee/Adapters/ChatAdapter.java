package com.example.testeeee.Adapters;

import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.testeeee.Modelo.ChatMessage;
import com.example.testeeee.databinding.ItemContainerMensagemBinding;
import com.example.testeeee.databinding.ItemContainerMsgRecebidaBinding;

import java.util.List;

public class ChatAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private final List<ChatMessage> chatMessages;
    private final Bitmap receiverProfileImagem;
    private final String senderId;

    public static final int VIEW_TYPE_SENT = 1;
    public static final int VIEW_TYPE_RECEIVED = 2;


    public ChatAdapter(List<ChatMessage> chatMessages, Bitmap receiverProfileImagem, String senderId) {
        this.chatMessages = chatMessages;
        this.receiverProfileImagem = receiverProfileImagem;
        this.senderId = senderId;
    }



    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if(viewType == VIEW_TYPE_SENT){
            return new SentMenssageViewHolder(
                    ItemContainerMensagemBinding.inflate(
                            LayoutInflater.from(parent.getContext()), parent, false
                    )
            );
        }else {
            return  new ReceivedMenssageViewHolder(
                    ItemContainerMsgRecebidaBinding.inflate(
                            LayoutInflater.from(parent.getContext()), parent, false
                    )
            );
        }

    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
            if(getItemViewType(position) == VIEW_TYPE_SENT){
                ((SentMenssageViewHolder) holder).setData(chatMessages.get(position));
            }else {
                ((ReceivedMenssageViewHolder) holder).setData(chatMessages.get(position), receiverProfileImagem);
            }
    }

    @Override
    public int getItemCount() {
        return chatMessages.size();
    }

    @Override
    public int getItemViewType(int position) {
         if(chatMessages.get(position).senderId.equals(senderId)){
             return VIEW_TYPE_SENT;
         }else {
             return VIEW_TYPE_RECEIVED;
         }
    }

    static class SentMenssageViewHolder extends RecyclerView.ViewHolder{

        private final ItemContainerMensagemBinding binding;

        SentMenssageViewHolder(ItemContainerMensagemBinding itemContainerMensagemBinding){

            super(itemContainerMensagemBinding.getRoot());
            binding = itemContainerMensagemBinding;
        }

        void setData(ChatMessage chatMessage){
            try {
                binding.textoMensagem.setText(chatMessage.message);
                binding.textDataTime.setText(chatMessage.dateTime);
            }catch (Exception e){}

        }

    }

    static class ReceivedMenssageViewHolder extends RecyclerView.ViewHolder{

        private final ItemContainerMsgRecebidaBinding binding;

        ReceivedMenssageViewHolder(ItemContainerMsgRecebidaBinding itemContainerMsgRecebidaBinding){

            super(itemContainerMsgRecebidaBinding.getRoot());
            binding = itemContainerMsgRecebidaBinding;
        }
        void setData(ChatMessage chatMessage, Bitmap reciverProfileImage){
            try {
                binding.textoMensagemRecebida.setText(chatMessage.message);
                binding.textoDataTime.setText(chatMessage.dateTime);
                binding.imagemPerfilconversa.setImageBitmap(reciverProfileImage);
            }catch (Exception e){} //caso o usuario não tenha foto de perfil

        }
    }
}
