package com.example.testeeee.botnavegacao;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.testeeee.Funcionais.Btn;
import com.example.testeeee.R;
import com.example.testeeee.Adapters.RecyclerAdapter;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link Pagtemas#newInstance} factory method to
 * create an instance of this fragment.
 */
public class Pagtemas extends Fragment {
    RecyclerView rv;
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public Pagtemas() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment Pagtemas.
     */
    // TODO: Rename and change types and number of parameters
    public static Pagtemas newInstance(String param1, String param2) {
        Pagtemas fragment = new Pagtemas();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_pagtemas, container, false);


        String [] temasMatematica = {"Matrizes", "Determinante","Geometria Plana","Geometria Analítica","Funções", "Complexos", "Cálculo", "Trigonometria", "Algebra", "Aritmédica", "Polinômios", "Sistemas"};
        Btn matematica = new Btn("Matemática","ic_math", temasMatematica);

        String [] temasCiencias = { "Física aplicada", "Cinemática", "Dinâmica", "Estática", "Hidrostática", "Hidrodinâmica", "Termodinâmica", "MHS", "Ondulatória", "Óptica Geométrica", "Acústica", "Eletrostática", "Eletrodinâmica", "Eletromagnetismo", "Física Moderna", "Astronomia", "Modelos Atômicos", "Tabela Periódica", "Ligacões Químicas", "Inorgânica", "Reações Químicas", "Estudo Quantitativo", "Estequiometria", "Soluções", "Propiedade Coligativa", "Termoquímica", "Cinética Química", "Equilíbrio Químico", "Eletroquímica", "Agricultura", "Anatomia", "Bioquímica", "Biologia", "Botânica", "Química", "Ecologia", "Ciência ambiental", "Genética", "Geologia", "Microbiologia"};
        Btn ciencias = new Btn("Ciências","ic_ciencia",temasCiencias);
        Btn programacao = new Btn("Programação", "ic_programacao");
        Btn economia = new Btn("Economia","ic_economia");
        Btn medicina = new Btn("Medicina", "ic_medicina");
        Btn arquitetura = new Btn("Arquitetura", "ic_arquitetura");
        Btn lei = new Btn("Lei", "ic_lei");
        Btn engenharia = new Btn("Engenharia", "ic_engenharia");
        Btn arte = new Btn("Arte", "ic_arte");
        Btn lingugens = new Btn("Linguagens","ic_linguagens");
        Btn humanas = new Btn("Humanas","ic_humanas");
        Btn administracao = new Btn("Administração","ic_administracao");
        ArrayList<Btn> lista = new ArrayList<>();
        lista.add(matematica);
        lista.add(ciencias);
        lista.add(programacao);
        lista.add(economia);
        lista.add(medicina);
        lista.add(arquitetura);
        lista.add(lei);
        lista.add(engenharia);
        lista.add(arte);
        lista.add(lingugens);
        lista.add(humanas);
        lista.add(administracao);





        rv = v.findViewById(R.id.rv);
        rv.setHasFixedSize(true);
        rv.setLayoutManager(new LinearLayoutManager(getContext()));
        RecyclerAdapter adaptador = new RecyclerAdapter(getContext(), lista);
        rv.setAdapter(adaptador);
        adaptador.notifyDataSetChanged();
        return v;
    }
}