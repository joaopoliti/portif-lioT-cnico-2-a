package com.example.testeeee.Fragmentos;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.widget.AppCompatButton;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;

import com.example.testeeee.Funcionais.Constantes;
import com.example.testeeee.Funcionais.PreferenceManager;
import com.example.testeeee.R;
import com.example.testeeee.activityss.home;
import com.example.testeeee.firebase.UsuarioBD;
import com.example.testeeee.databinding.FragmentFcadastroBinding;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;


public class fcadastro extends Fragment {

    EditText nome2, senha2, data;
    AppCompatButton cadastro;
    private FragmentFcadastroBinding binding;
    private PreferenceManager preferenceManager;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        binding = FragmentFcadastroBinding.inflate(inflater, container, false);

        nome2 = binding.getRoot().findViewById(R.id.nome2);
        senha2 = binding.getRoot().findViewById(R.id.senha2);
        cadastro = (AppCompatButton)binding.getRoot().findViewById(R.id.cadastro);
        data = binding.getRoot().findViewById(R.id.data);
        setListener();
        preferenceManager = new PreferenceManager(getContext());
        return binding.getRoot();



    }
    private void setListener(){
        binding.cadastro.setOnClickListener(v -> {
            if(eValidoCadastroDetelhes()){
                cadatrar();
            }
        });
    }

    private void cadatrar(){
    FirebaseFirestore database = FirebaseFirestore.getInstance();
        HashMap<String, Object> user = new HashMap<>();
        user.put(Constantes.KEY_NOME, binding.nome2.getText().toString());
        user.put(Constantes.KEY_SENHA, senha2.getText().toString());
        user.put(Constantes.KEY_DATA, data.getText().toString() +"");
        database.collection(Constantes.KEY_COLLECTION_USER)
                .add(user)
                .addOnSuccessListener(documentReference -> {
                    preferenceManager.putBoolean(Constantes.KEY_IS_SIGNED_IN, true);
                    preferenceManager.putString(Constantes.KEY_USER_ID, documentReference.getId());
                    preferenceManager.putString(Constantes.KEY_NOME, binding.nome2.getText().toString());
                    Intent i = new Intent(getContext(), home.class);
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(i);
                })
                .addOnFailureListener(exception -> {
                    showToast(exception.getMessage());
                });
    }

    private void showToast( String menssage){
        Toast.makeText(getContext(),menssage, Toast.LENGTH_SHORT).show();
    }

    private boolean eValidoCadastroDetelhes(){
        if(binding.nome2.getText().toString().trim().isEmpty()){
        showToast("Coloque o nome");
        return false;
        }
        else if (binding.senha2.getText().toString().trim().isEmpty()){
            showToast("Coloque a senha");
            return false;
        }
        else if(binding.data.getText().toString().trim().isEmpty()){
            showToast("Coloque a data de nascimento");
            return false;
        }
        else{
            return true;
        }
    }

}