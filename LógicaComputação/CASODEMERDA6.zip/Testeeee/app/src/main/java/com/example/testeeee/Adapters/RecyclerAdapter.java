package com.example.testeeee.Adapters;

import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.recyclerview.widget.RecyclerView;

import com.example.testeeee.Funcionais.Btn;
import com.example.testeeee.R;
import com.example.testeeee.activityss.Tela_temas;

import java.util.ArrayList;

public class RecyclerAdapter extends RecyclerView.Adapter<RecyclerAdapter.MyViewHolder> {
    Context context;
    ArrayList<Btn> list;
    RecyclerAdapter.OnItemClickListener listener;
    public RecyclerAdapter(Context context, ArrayList<Btn> list) {
        this.context = context;
        this.list = list;

    }

    public RecyclerAdapter(Context context, ArrayList<Btn> list, OnItemClickListener listener) {
        this.context = context;
        this.list = list;
        this.listener = listener;
    }

    @NonNull
    @Override


    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.layout,parent,false);

        return new RecyclerAdapter.MyViewHolder(v);
    }

    @RequiresApi(api = Build.VERSION_CODES.Q)
    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        Btn botao = list.get(position);
        holder.btn.setText(botao.texto);
        Drawable img = getImage(context, botao.icon);
        img.setBounds(0,0,60,60);
        holder.btn.setCompoundDrawables(img,null,null,null);
        holder.btn.setOnClickListener(view ->{
            Tela_temas.texto = botao.getTexto();
            Tela_temas.temas = botao.getTemas();
            Intent i = new Intent(context, Tela_temas.class);
            context.startActivity(i);
        });
    }
    @RequiresApi(api = Build.VERSION_CODES.Q)
    public static Drawable getImage(Context c, String imageName){
        return c.getResources().getDrawable(c.getResources().getIdentifier(imageName,"drawable", c.getOpPackageName()));
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public interface OnItemClickListener {
        void onItemClick(Btn btn);
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        Button btn;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            btn = itemView.findViewById(R.id.botao);
        }
    }
}
