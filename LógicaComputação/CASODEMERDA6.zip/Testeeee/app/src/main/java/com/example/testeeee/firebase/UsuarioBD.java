package com.example.testeeee.firebase;


import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class UsuarioBD {
    private  String nome;
    private  String senha;
    private String idade;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public String getIdade() {
        return idade;
    }

    public void setIdade(String idade) {
        this.idade = idade;
    }


    public void salvar ( ) {
        DatabaseReference reference = FirebaseDatabase.getInstance ( ) . getReference ( ) ;

        reference.child ( " Usuarios " ) . child ( nome ) .setValue ( this ) ;
    }
}
