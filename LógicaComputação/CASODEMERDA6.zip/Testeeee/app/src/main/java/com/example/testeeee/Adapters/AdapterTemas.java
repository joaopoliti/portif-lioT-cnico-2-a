package com.example.testeeee.Adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.testeeee.R;

public class AdapterTemas extends RecyclerView.Adapter<AdapterTemas.MyViewHolder> {
    Context context;
    String [] temas;

    public AdapterTemas(Context context, String[] temas) {
        this.context = context;
        this.temas = temas;
    }

    @NonNull
    @Override
    public AdapterTemas.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.layout_disciplinas,parent,false);

        return new AdapterTemas.MyViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull AdapterTemas.MyViewHolder holder, int position) {
        String botao = temas[position];
        holder.btn.setText(botao);
        holder.btn.setOnClickListener(view ->{
            //click no botao do tema
        });
    }

    @Override
    public int getItemCount() {
        return temas.length;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        Button btn;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            btn = itemView.findViewById(R.id.botao_tema);
        }
    }
}
