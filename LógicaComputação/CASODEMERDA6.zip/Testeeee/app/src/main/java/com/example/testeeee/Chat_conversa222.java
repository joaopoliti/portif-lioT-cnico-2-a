package com.example.testeeee;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.testeeee.Funcionais.Constantes;
import com.example.testeeee.Modelo.User;
import com.example.testeeee.databinding.ActivityChatConversa222Binding;
import com.example.testeeee.databinding.FragmentChatConversaBinding;

public class Chat_conversa222 extends AppCompatActivity {

    private ActivityChatConversa222Binding binding;
    private User receiverUser;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityChatConversa222Binding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        loadReciverDetelhes();
        setListener();
    }
    private void loadReciverDetelhes(){
        receiverUser = (User) getIntent().getSerializableExtra(Constantes.KEY_USUARIO);
        binding.textNome.setText(receiverUser.nome);
    }
    private void setListener(){
        binding.imageBack.setOnClickListener(v -> onBackPressed());
    }
}