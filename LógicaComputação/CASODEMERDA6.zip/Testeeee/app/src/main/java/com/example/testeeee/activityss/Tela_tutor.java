package com.example.testeeee.activityss;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.view.MenuItem;

import com.example.testeeee.R;
import com.example.testeeee.btnnavegatutor.Chat_Tutor;
import com.example.testeeee.btnnavegatutor.Perfil_Tutor;
import com.example.testeeee.btnnavegatutor.Perguntas;
import com.example.testeeee.databinding.ActivityMainBinding;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;

public class Tela_tutor extends AppCompatActivity {

    ActivityMainBinding binding;
    BottomNavigationView bottomNavigationtutor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_tutor);
        fragmentRepl(new Perguntas());
        bottomNavigationtutor = findViewById(R.id.btNVtutor);
        bottomNavigationtutor.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {

                switch (item.getItemId()){


                    case R.id.perguntas:

                        fragmentRepl(new Perguntas());

                        return true;


                    case R.id.chat_tutor:

                        fragmentRepl(new Chat_Tutor());

                        return true;


                    case R.id.perfil_Tutor:

                        fragmentRepl(new Perfil_Tutor());

                        return true;



                }



                return false;
            }
        });
        Fragment fragment = getSupportFragmentManager().findFragmentById(R.id.fragmentContainerView);
    }
    public  interface IOnBackPressed{
        boolean onBackPressed();
    }
    private void fragmentRepl(Fragment fragment){

        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.container_tutor,fragment);
        fragmentTransaction.commit();

    }
    }
