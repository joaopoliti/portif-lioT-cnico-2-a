package com.example.testeeee.botnavegacao;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatButton;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.testeeee.Funcionais.Constantes;
import com.example.testeeee.Funcionais.PreferenceManager;
import com.example.testeeee.R;
import com.example.testeeee.activityss.MainActivity;
import com.example.testeeee.activityss.Tela_minhaPergunta;
import com.example.testeeee.activityss.Tela_tutor;
import com.example.testeeee.activityss.home;
import com.example.testeeee.databinding.FragmentPerfilBinding;
import com.example.testeeee.firebase.UsuarioBD;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.StorageReference;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.HashMap;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link Perfil#newInstance} factory method to
 * create an instance of this fragment.
 */
public class Perfil extends Fragment  {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";


    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public Perfil() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment Perfil.
     */
    // TODO: Rename and change types and number of parameters
    public static Perfil newInstance(String param1, String param2) {
        Perfil fragment = new Perfil();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }
    public static UsuarioBD usuarioBD;
    StorageReference storageRef;
    Uri mselUri;
    ImageView foto;
    AppCompatButton btperguntas, btTutor;
    private FragmentPerfilBinding binding;
     PreferenceManager preferenceManager;
     private String ecodeImage;
      private FirebaseFirestore firestore;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentPerfilBinding.inflate(inflater, container, false);
        foto = binding.getRoot().findViewById(R.id.imagemPerfil);
        btperguntas = (AppCompatButton)binding.getRoot().findViewById(R.id.btperguntas);
        btTutor = (AppCompatButton)binding.getRoot().findViewById(R.id.btTutor);
        preferenceManager = new PreferenceManager(getContext());
        setListener();
        setListener2();



        binding.imagemPerfil.setOnClickListener(v ->{
            Intent i = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            i.addFlags(i.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            pickImagem.launch(i);
        });
        firestore = FirebaseFirestore.getInstance();
        pegarFoto();
        return binding.getRoot();
    }

    private void setListener(){
        binding.saida.setOnClickListener(v -> saida());

    }


    private void print(String msg) {
        Toast.makeText(getContext(), msg, Toast.LENGTH_LONG).show();
    }




    private  String ecodeImage(Bitmap bitmap){
        int previewWidth = 150;
        int previewHeight = bitmap.getHeight() * previewWidth / bitmap.getWidth();
        Bitmap previewBitmap = Bitmap.createScaledBitmap(bitmap, previewWidth, previewHeight, false);
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        previewBitmap.compress(Bitmap.CompressFormat.JPEG, 50, byteArrayOutputStream);
        byte [] bytes = byteArrayOutputStream.toByteArray();
        return Base64.encodeToString(bytes, Base64.DEFAULT);

    }

    private final ActivityResultLauncher<Intent> pickImagem = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if(result.getResultCode() == -1){
                    if(result.getData() != null){
                        Uri imagemUri = result.getData().getData();
                        try {
                            InputStream inputStream = getContext().getContentResolver().openInputStream(imagemUri);
                            Bitmap bitmap = BitmapFactory.decodeStream(inputStream);
                            binding.imagemPerfil.setImageBitmap(bitmap);
                            ecodeImage = ecodeImage(bitmap);

                            salvarFOTO(ecodeImage);

                        }catch (FileNotFoundException e){
                            e.printStackTrace();
                        }
                    }
                }
            }


    );
    private void setListener2(){

        binding.btTutor.setOnClickListener(v -> tela_tutor());
    }

    private void tela_tutor(){

        startActivity(new Intent(getContext(), Tela_tutor.class));
    }

    private void Listenerpergunta(){

        binding.btTutor.setOnClickListener(v -> tela_mnPergunta());
    }

    private void tela_mnPergunta(){
        startActivity(new Intent(getContext(), Tela_minhaPergunta.class));
    }

    private void saida(){
        FirebaseFirestore database = FirebaseFirestore.getInstance();
        DocumentReference documentReference =
                database.collection(Constantes.KEY_COLLECTION_USER).document(
                        preferenceManager.getString(Constantes.KEY_USER_ID, null)
                );
        HashMap<String, Object> updates = new HashMap<>();
        updates.put(Constantes.KEY_FCM_TOKEN, FieldValue.delete());
        documentReference.update(updates)
                .addOnSuccessListener(unused -> {
                    preferenceManager.clear();
                    startActivity(new Intent(getContext(), MainActivity.class));
                })
                .addOnFailureListener(e -> print("Não foi possivel sair"));

    }
    private void salvarFOTO(String foto){
        FirebaseFirestore database = FirebaseFirestore.getInstance();
        DocumentReference documentReference =
                database.collection(Constantes.KEY_COLLECTION_USER).document(
                        preferenceManager.getString(Constantes.KEY_USER_ID, foto));
        documentReference.update(Constantes.KEY_IMAGE, foto)
                .addOnSuccessListener(unused -> print("Token atualizado"))
                .addOnFailureListener(e -> print("Não foi possivel atualizaro token"));


    }
    public void pegarFoto(){
        DocumentReference reference = firestore.collection("users").document(preferenceManager.getString(Constantes.KEY_USER_ID, null));

        reference.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if(task.isSuccessful()){
                    DocumentSnapshot documentSnapshot = task.getResult();
                    if(documentSnapshot.exists()){
                        try {
                            String informacaoFoda = (String) documentSnapshot.getData().get(Constantes.KEY_IMAGE);
                            byte[] bytes = Base64.decode(informacaoFoda,Base64.DEFAULT);
                            Bitmap bitmap = BitmapFactory.decodeByteArray(bytes,0, bytes.length);
                            binding.imagemPerfil.setImageBitmap(bitmap);
                            Log.d(Constantes.KEY_IMAGE, informacaoFoda);
                        }catch (Exception e){}

                    }
                }else{}
            }
        });
    }



    }
