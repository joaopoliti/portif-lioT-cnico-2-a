package com.example.testeeee.Fragmentos;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.widget.AppCompatButton;
import androidx.fragment.app.Fragment;

import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Toast;

import com.example.testeeee.Funcionais.Constantes;
import com.example.testeeee.Funcionais.PreferenceManager;
import com.example.testeeee.R;
import com.example.testeeee.firebase.UsuarioBD;
import com.example.testeeee.activityss.home;
import com.example.testeeee.databinding.FragmentLoginBinding;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;


public class login extends Fragment {

    EditText nome, senha;
    AppCompatButton entrar;
    CheckBox checkBox;
    private FragmentLoginBinding binding;
    private PreferenceManager preferenceManager;

    UsuarioBD u;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
         binding = FragmentLoginBinding.inflate(inflater, container, false);
        binding = FragmentLoginBinding.inflate(getLayoutInflater());
        setListener();
        preferenceManager = new PreferenceManager(getContext());
        if (preferenceManager.getBoolean(Constantes.KEY_IS_SIGNED_IN)){
            Intent i = new Intent(getContext(), home.class);
            startActivity(i);

        }
        nome = binding.getRoot().findViewById(R.id.nome);
        senha = binding.getRoot().findViewById(R.id.senha);
        checkBox = binding.getRoot().findViewById(R.id.checkBox);
        entrar = (AppCompatButton) binding.getRoot().findViewById(R.id.entrar);


        checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

            @Override

            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

                if (isChecked) {

                    senha.setTransformationMethod(HideReturnsTransformationMethod.getInstance());

                } else {

                    senha.setTransformationMethod(PasswordTransformationMethod.getInstance());
                }
            }
        });

        return binding.getRoot();
    }



    private void setListener(){
        binding.entrar.setOnClickListener(v ->
                startActivity(new Intent(getContext(),home.class)));
        binding.entrar.setOnClickListener(v -> {
            if(eValidoEntraremDetalhes());
            entrando();
        });
    }

    private void entrando(){
        FirebaseFirestore database = FirebaseFirestore.getInstance();
        database.collection(Constantes.KEY_COLLECTION_USER)
                .whereEqualTo(Constantes.KEY_NOME, binding.nome.getText().toString())
                .whereEqualTo(Constantes.KEY_SENHA, binding.senha.getText().toString())
                .get()
                .addOnCompleteListener(task -> {
                    if(task.isSuccessful() && task.getResult() != null
                    && task.getResult().getDocuments().size() > 0) {
                        DocumentSnapshot documentSnapshot = task.getResult().getDocuments().get(0);
                        preferenceManager.putBoolean(Constantes.KEY_IS_SIGNED_IN, true);
                        preferenceManager.putString(Constantes.KEY_USER_ID, documentSnapshot.getId());
                        preferenceManager.putString(Constantes.KEY_NOME, documentSnapshot.getString(Constantes.KEY_NOME));
                        preferenceManager.putString(Constantes.KEY_IMAGE, documentSnapshot.getString(Constantes.KEY_IMAGE));
                        Intent i = new Intent(getContext(), home.class);
                        i.addFlags(i.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(i);

                    }else{
                        print("Coloque um usuario valido");
                    }
                });


    }


    private void print(String msg) {
        Toast.makeText(getContext(), msg, Toast.LENGTH_LONG).show();
    }

    private Boolean eValidoEntraremDetalhes(){
        if(binding.nome.getText().toString().trim().isEmpty()){
            print("Coloque o nome");
            return false;
        }else if (binding.senha.getText().toString().trim().isEmpty()){
            print("Coloque a senha");
            return false;
        }else {
            return true;
        }
    }
}