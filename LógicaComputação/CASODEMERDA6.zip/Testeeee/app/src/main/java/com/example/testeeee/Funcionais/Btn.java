package com.example.testeeee.Funcionais;

import java.util.ArrayList;

public class Btn {
    public String texto;
    public String icon;
    String[] temas;

    public Btn(String texto, String icon) {
        this.texto = texto;
        this.icon = icon;
    }

    public String getTexto() {
        return texto;
    }

    public void setTexto(String texto) {
        this.texto = texto;
    }

    public String[] getTemas() {
        return temas;
    }

    public void setTemas(String[] temas) {
        this.temas = temas;
    }

    public Btn(String texto, String icon, String[] temas) {
        this.texto = texto;
        this.icon = icon;
        this.temas = temas;
    }
}
