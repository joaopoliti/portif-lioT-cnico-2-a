package com.example.testeeee.activityss;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;


import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Toast;

import com.example.testeeee.Funcionais.Constantes;
import com.example.testeeee.Funcionais.PreferenceManager;
import com.example.testeeee.R;
import com.example.testeeee.botnavegacao.Addpergunta;
import com.example.testeeee.botnavegacao.Chat;
import com.example.testeeee.botnavegacao.Pagtemas;
import com.example.testeeee.botnavegacao.Perfil;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.messaging.FirebaseMessaging;

public class home extends AppCompatActivity {


    BottomNavigationView bottomNavigation;
    private PreferenceManager preferenceManager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        fragmentRepl(new Pagtemas());
        preferenceManager = new PreferenceManager(this);
        getToken();



        bottomNavigation = findViewById(R.id.bottomNavigationView);
        bottomNavigation.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {

                switch (item.getItemId()){


                    case R.id.pagtemas:

                        fragmentRepl(new Pagtemas());

                        return true;

                    case R.id.addpergunta:

                        fragmentRepl(new Addpergunta());

                        return true;


                    case R.id.chat:

                        fragmentRepl(new Chat());

                        return true;


                    case R.id.perfil:

                        fragmentRepl(new Perfil());

                        return true;



                }



                return false;
            }
        });
        Fragment fragment = getSupportFragmentManager().findFragmentById(R.id.fragmentContainerView);
    }
    public  void voltaMinhaPergunta(){
        fragmentRepl(new Perfil());
    }

    private void fragmentRepl(Fragment fragment){

        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.nav_host_fragment,fragment);
        fragmentTransaction.commit();

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent i = new Intent(this,Perfil.class);
        startActivity(i);
    }

    private void getToken(){
        FirebaseMessaging.getInstance().getToken().addOnSuccessListener(this::atualizaToken);

    }

    private void atualizaToken(String token){
        FirebaseFirestore database = FirebaseFirestore.getInstance();
        DocumentReference documentReference =
                database.collection(Constantes.KEY_COLLECTION_USER).document(
                        preferenceManager.getString(Constantes.KEY_USER_ID, token));
        documentReference.update(Constantes.KEY_FCM_TOKEN, token)
                .addOnSuccessListener(unused -> print("Token atualizado"))
                .addOnFailureListener(e -> print("Não foi possivel atualizaro token"));
    }
    private void print(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
    }
}