package com.example.testeeee.botnavegacao;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterViewAnimator;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;

import com.example.testeeee.R;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link Addpergunta#newInstance} factory method to
 * create an instance of this fragment.
 */
public class Addpergunta extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public Addpergunta() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment Addpergunta.
     */
    // TODO: Rename and change types and number of parameters
    public static Addpergunta newInstance(String param1, String param2) {
        Addpergunta fragment = new Addpergunta();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }
String[] roger = {"Matemática", "Ciências", "Programação", "Economia", "Medicina", "Arquitetura", "Lei", "Engenharia", "Arte","Linguagens", "Humanas", "Adminiistração"};
    String[] roger2 = {"Matemática", "Ciências", "Programação", "Economia", "Medicina", "Arquitetura", "Lei", "Engenharia", "Arte","Linguagens", "Humanas", "Adminiistração"};
String [] valor = {"R$ 5,00", "R$ 10,00", "R$ 15,00", "R$ 20,00", "R$ 25,00", "R$ 30,00", "R$ 35,00", "R$ 40,00", "R$ 50,00" };
AutoCompleteTextView autoComplete, autocompleteTema, autocompleteValor;

ArrayAdapter<String> adapterItems, adapterItemTema, adapterItemValor;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v =inflater.inflate(R.layout.fragment_addpergunta, container, false);


            autoComplete = v.findViewById(R.id.autoComplete);
            autocompleteTema = v.findViewById(R.id.autoCompleteTema);
            autocompleteValor = v.findViewById(R.id.autoCompleteValor);

            adapterItems = new ArrayAdapter<String>(getContext(),R.layout.list_item,roger);
            adapterItemTema= new ArrayAdapter<String>(getContext(),R.layout.list_item,roger2);
            adapterItemValor = new ArrayAdapter<String>(getContext(),R.layout.list_item,valor);

            autoComplete.setAdapter(adapterItems);
            autocompleteTema.setAdapter(adapterItemTema);
            autocompleteValor.setAdapter(adapterItemValor);


            autocompleteValor.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                }
            });


            autocompleteTema.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                }
            });

            autoComplete.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                }
            });


        return v;
    }
}