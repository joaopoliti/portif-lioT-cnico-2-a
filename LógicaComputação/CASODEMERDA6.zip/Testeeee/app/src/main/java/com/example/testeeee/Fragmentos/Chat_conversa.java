package com.example.testeeee.Fragmentos;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.testeeee.Funcionais.Constantes;
import com.example.testeeee.Modelo.User;
import com.example.testeeee.R;
import com.example.testeeee.databinding.FragmentChatConversaBinding;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link Chat_conversa#newInstance} factory method to
 * create an instance of this fragment.
 */
public class Chat_conversa extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public Chat_conversa() {
        // Required empty public constructor
    }


    // TODO: Rename and change types and number of parameters
    public static Chat_conversa newInstance(String param1, String param2) {
        Chat_conversa fragment = new Chat_conversa();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    private FragmentChatConversaBinding binding;
    private User receiverUser;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        binding =  FragmentChatConversaBinding.inflate(inflater, container, false);

        return binding.getRoot();
    }



}