package com.example.testeeee.Funcionais;

public class Constantes {

    public static final String KEY_COLLECTION_USER = "users";
    public static final String KEY_NOME = "nome";
    public static final String KEY_SENHA = "senha";
    public static final String KEY_PRAFARENCE_NAME = "chatAppPreference";
    public static final String KEY_USER_ID = "userId";
    public static final String KEY_FCM_TOKEN = "fcmToken";
    public static final String KEY_IMAGE = "image";
    public static final String KEY_IS_SIGNED_IN = "isSignedIn";
    public static final String KEY_DATA = "data";
    public static final String KEY_USUARIO = "usuario";









}
