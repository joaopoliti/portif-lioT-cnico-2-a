package com.example.testeeee.activityss;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.viewpager2.widget.ViewPager2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import com.example.testeeee.Adapters.AdapterPagerPerguntas;
import com.example.testeeee.R;
import com.example.testeeee.firebase.UsuarioBD;
import com.example.testeeee.botnavegacao.Perfil;
import com.google.android.material.tabs.TabLayout;

public class Tela_minhaPergunta extends AppCompatActivity {

    ViewPager2 viewPager2;
    TabLayout tabLayout;
    AdapterPagerPerguntas adaptador;
    ImageView imgBack;
    public static UsuarioBD usu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_minha_pergunta);
        viewPager2 = findViewById(R.id.view);
        tabLayout = findViewById(R.id.tabLayout);
        imgBack= findViewById(R.id.imgback);
        FragmentManager fm = getSupportFragmentManager();
        adaptador = new AdapterPagerPerguntas(fm,getLifecycle()); //atributos do contrutor
        viewPager2.setAdapter(adaptador);
        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {// vincular os fragmentos as tabs
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                viewPager2.setCurrentItem(tab.getPosition()); // vincular a tab com a position | 0 - pri | 1 - Segu | 2 - Ter


            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });
        viewPager2.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override//qual página está selecionada, vamo usar para passar para o tab
            public void onPageSelected(int position) {
                super.onPageSelected(position);
                tabLayout.selectTab(tabLayout.getTabAt(position)); //setar no tab a posição
            }
        });
        imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Tela_minhaPergunta.this, home.class);
                startActivity(i);
                Perfil.usuarioBD = usu;
            }
        });
    }

}