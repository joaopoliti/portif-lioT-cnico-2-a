package com.example.testeeee.activityss;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.viewpager2.widget.ViewPager2;

import android.content.Intent;
import android.os.Bundle;


import com.example.testeeee.Adapters.Adapter;
import com.example.testeeee.R;
import com.example.testeeee.firebase.UsuarioBD;
import com.google.android.material.tabs.TabLayout;
import com.google.firebase.auth.FirebaseAuth;


public class MainActivity extends AppCompatActivity {

    private FirebaseAuth mAuth;
    private UsuarioBD u;
    Adapter adapter;
    ViewPager2 viewPager2;
    TabLayout tabLayout;

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent i = new Intent(this,MainActivity.class);
        startActivity(i);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mAuth = FirebaseAuth.getInstance();
        viewPager2 = findViewById(R.id.viewPager);
        tabLayout = findViewById(R.id.tabbar);
        mAuth = FirebaseAuth.getInstance();
        tabLayout.addTab(tabLayout.newTab().setText("Login"));
        tabLayout.addTab(tabLayout.newTab().setText("Cadastro"));



        FragmentManager fm = getSupportFragmentManager();
        adapter = new Adapter(fm,getLifecycle()); //atributos do contrutor
        viewPager2.setAdapter(adapter);

        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {// vincular os fragmentos as tabs
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                viewPager2.setCurrentItem(tabLayout.getSelectedTabPosition()); // vincular a tab com a position | 0 - pri | 1 - Segu | 2 - Ter


            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });
        viewPager2.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override//qual página está selecionada, vamo usar para passar para o tab
            public void onPageSelected(int position) {
                super.onPageSelected(position);
                tabLayout.selectTab(tabLayout.getTabAt(position)); //setar no tab a posição
            }
        });


    }



    }
